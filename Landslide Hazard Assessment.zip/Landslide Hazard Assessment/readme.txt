Name of the program：landslide hazard assessment
Title of the manuscript：Research on Landslide Hazard Assessment Based on IV-SVM
Author details：Li Xia（College of Geoscience and Surveying Engineering, China University of Mining and Technology (Beijing)）
                         Cheng Jiulong（* Corresponding author，College of Geoscience and Surveying Engineering, China University of Mining and Technology (Beijing)）
                         Yu Dehao（Research Institut of Engineering Design, Beijing）
                         Han Yangchun（College of Geoscience and Surveying Engineering, China University of Mining and Technology (Beijing)）
